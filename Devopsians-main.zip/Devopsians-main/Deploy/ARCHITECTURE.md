# 🏗️ Devopsians Deployment Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    Devopsians Application Stack                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                       Environment Layer                          │
├─────────────────────────────────────────────────────────────────┤
│  Development  │  Staging  │  Production                          │
│  localhost    │  staging  │  production                          │
└────────┬──────┴─────┬─────┴─────┬───────────────────────────────┘
         │            │           │
         └────────────┴───────────┘
                  │
         ┌────────▼──────────┐
         │   Docker Compose  │
         │  Orchestration    │
         └────────┬──────────┘
                  │
    ┌─────────────┼─────────────┐
    │             │             │
┌───▼────┐   ┌───▼────┐   ┌───▼────┐
│Frontend│   │Backend │   │MongoDB │
│:80     │◄──│:3030   │◄──│:27017  │
└────────┘   └────────┘   └────────┘
   Nginx      Node.js      Database
   React       Express
```

## Service Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         Client Browser                           │
└────────────────────────────┬────────────────────────────────────┘
                             │ HTTP/HTTPS
                ┌────────────▼───────────────┐
                │     Frontend Service       │
                │  (React + Vite + Nginx)   │
                │      Port: 80/443         │
                └────────────┬───────────────┘
                             │ API Calls
                ┌────────────▼───────────────┐
                │     Backend Service        │
                │   (Node.js + Express)      │
                │       Port: 3030           │
                └────────────┬───────────────┘
                             │ Database Queries
                ┌────────────▼───────────────┐
                │    MongoDB Service         │
                │     (Database)             │
                │       Port: 27017          │
                └────────────────────────────┘
```

## Container Network

```
┌─────────────────────────────────────────────────────────────────┐
│                   devopsians-net-{environment}                   │
│                        Docker Bridge Network                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌───────────────────┐  ┌───────────────────┐  ┌─────────────┐│
│  │   Frontend        │  │   Backend         │  │   MongoDB   ││
│  │                   │  │                   │  │             ││
│  │ Container:        │  │ Container:        │  │ Container:  ││
│  │ devopsians-       │  │ devopsians-       │  │ devopsians- ││
│  │ frontend-{env}    │  │ backend-{env}     │  │ mongodb     ││
│  │                   │  │                   │  │             ││
│  │ Health: ✓         │  │ Health: ✓         │  │ Health: ✓   ││
│  │ Restart: always   │  │ Restart: always   │  │ Restart:    ││
│  │                   │  │                   │  │ always      ││
│  └───────────────────┘  └───────────────────┘  └─────────────┘│
│         │                       │                      │        │
│         │                       │                      │        │
│   Port: 80/443            Port: 3030            Port: 27017    │
│         │                       │                      │        │
└─────────┼───────────────────────┼──────────────────────┼────────┘
          │                       │                      │
          └───────────────────────┴──────────────────────┘
                              │
                    ┌─────────▼──────────┐
                    │    Host Machine     │
                    │   (Your Server)     │
                    └────────────────────┘
```

## Volume Management

```
┌─────────────────────────────────────────────────────────────────┐
│                         Docker Volumes                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  devopsians-mongodb-data-{environment}                   │  │
│  │  └─ Stores: Database collections, indexes, data         │  │
│  │     Mounted: /data/db                                    │  │
│  │     Persistent: Yes                                      │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  devopsians-mongodb-config-{environment}                 │  │
│  │  └─ Stores: MongoDB configuration files                 │  │
│  │     Mounted: /data/configdb                              │  │
│  │     Persistent: Yes                                      │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Health Check Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                      Health Check Sequence                       │
└─────────────────────────────────────────────────────────────────┘

1. MongoDB Start
   ├─ Container starts
   ├─ Health check: mongosh ping
   ├─ Interval: every 10 seconds
   ├─ Timeout: 5 seconds
   └─ Status: ✓ Healthy

          ↓ (waits for healthy)

2. Backend Start
   ├─ Container starts (after MongoDB healthy)
   ├─ Connects to MongoDB
   ├─ Health check: HTTP GET /health
   ├─ Interval: every 30 seconds
   ├─ Timeout: 10 seconds
   ├─ Start period: 40 seconds
   └─ Status: ✓ Healthy

          ↓ (waits for healthy)

3. Frontend Start
   ├─ Container starts (after Backend healthy)
   ├─ Nginx serves React build
   ├─ Health check: HTTP GET /
   ├─ Interval: every 30 seconds
   ├─ Timeout: 10 seconds
   ├─ Start period: 20 seconds
   └─ Status: ✓ Healthy

          ↓

4. System Ready
   └─ All services operational ✓
```

## Environment Configuration Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    Environment Detection                         │
└─────────────────────────────────────────────────────────────────┘

                    ┌──────────────┐
                    │ deploy.sh    │
                    │ deploy.bat   │
                    └──────┬───────┘
                           │
                    ┌──────▼────────┐
                    │ .env exists?  │
                    └──────┬────────┘
                           │
                  ┌────────┴────────┐
                  │                 │
                 YES               NO
                  │                 │
          ┌───────▼───────┐   ┌────▼────────┐
          │  Use existing │   │ Detect env  │
          │  .env file    │   │ by hostname │
          └───────┬───────┘   └────┬────────┘
                  │                │
                  │         ┌──────▼────────────┐
                  │         │ • prod/production │
                  │         │ • staging/stg     │
                  │         │ • other = dev     │
                  │         └──────┬────────────┘
                  │                │
                  │         ┌──────▼────────────┐
                  │         │ User confirmation │
                  │         └──────┬────────────┘
                  │                │
                  │         ┌──────▼────────────┐
                  │         │ Copy .env.{ENV}   │
                  │         │ to .env           │
                  │         └──────┬────────────┘
                  │                │
                  └────────────────┘
                           │
                    ┌──────▼───────┐
                    │ Load config  │
                    │ from .env    │
                    └──────┬───────┘
                           │
                    ┌──────▼───────┐
                    │ docker       │
                    │ compose up   │
                    └──────────────┘
```

## Deployment Script Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                      Deployment Process                          │
└─────────────────────────────────────────────────────────────────┘

    ./deploy.sh
         │
    ┌────▼─────────────────────┐
    │ 1. Detect Environment    │
    │    - Check .env          │
    │    - Check hostname      │
    │    - Ask user            │
    └────┬─────────────────────┘
         │
    ┌────▼─────────────────────┐
    │ 2. Check Prerequisites   │
    │    - Docker installed?   │
    │    - Compose installed?  │
    └────┬─────────────────────┘
         │
    ┌────▼─────────────────────┐
    │ 3. Stop Containers       │
    │    docker compose down   │
    └────┬─────────────────────┘
         │
    ┌────▼─────────────────────┐
    │ 4. Pull Images           │
    │    docker compose pull   │
    └────┬─────────────────────┘
         │
    ┌────▼─────────────────────┐
    │ 5. Start Services        │
    │    docker compose up -d  │
    └────┬─────────────────────┘
         │
    ┌────▼─────────────────────┐
    │ 6. Wait for Health       │
    │    - MongoDB ready       │
    │    - Backend ready       │
    │    - Frontend ready      │
    └────┬─────────────────────┘
         │
    ┌────▼─────────────────────┐
    │ 7. Show Status           │
    │    - Service URLs        │
    │    - Container status    │
    └────┬─────────────────────┘
         │
    ┌────▼─────────────────────┐
    │ 8. Complete ✓            │
    │    System Ready          │
    └──────────────────────────┘
```

## Security Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      Security Layers                             │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ Layer 1: Network Security                                        │
├─────────────────────────────────────────────────────────────────┤
│ • Isolated Docker network per environment                        │
│ • Port exposure only where needed                                │
│ • Firewall rules on host                                         │
└─────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────▼───────────────────────────────────┐
│ Layer 2: Container Security                                      │
├─────────────────────────────────────────────────────────────────┤
│ • Non-root users in containers                                   │
│ • Read-only filesystems where possible                           │
│ • Resource limits                                                │
│ • Health checks                                                  │
└─────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────▼───────────────────────────────────┐
│ Layer 3: Application Security                                    │
├─────────────────────────────────────────────────────────────────┤
│ • JWT authentication                                             │
│ • Password hashing                                               │
│ • Input validation                                               │
│ • CORS configuration                                             │
└─────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────▼───────────────────────────────────┐
│ Layer 4: Data Security                                           │
├─────────────────────────────────────────────────────────────────┤
│ • MongoDB authentication                                         │
│ • Encrypted connections                                          │
│ • Persistent volumes                                             │
│ • Regular backups                                                │
└─────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────▼───────────────────────────────────┐
│ Layer 5: Configuration Security                                  │
├─────────────────────────────────────────────────────────────────┤
│ • Environment-specific secrets                                   │
│ • .env files not in Git                                          │
│ • Strong password requirements                                   │
│ • Secret rotation procedures                                     │
└─────────────────────────────────────────────────────────────────┘
```

## Monitoring Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      Monitoring Stack                            │
└─────────────────────────────────────────────────────────────────┘

         ┌────────────────────────┐
         │   monitor.sh/bat       │
         │   (Dashboard)          │
         └───────────┬────────────┘
                     │
         ┌───────────▼────────────┐
         │  Docker Compose        │
         │  Status & Logs         │
         └───────────┬────────────┘
                     │
     ┌───────────────┼───────────────┐
     │               │               │
┌────▼────┐    ┌────▼────┐    ┌────▼────┐
│Frontend │    │Backend  │    │MongoDB  │
│Health   │    │Health   │    │Health   │
│Check    │    │Check    │    │Check    │
└─────────┘    └─────────┘    └─────────┘
     │               │               │
     └───────────────┼───────────────┘
                     │
         ┌───────────▼────────────┐
         │   Logs & Metrics       │
         │   • Status: Up/Down    │
         │   • Response times     │
         │   • Error rates        │
         │   • Resource usage     │
         └────────────────────────┘
```

## Data Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                         Request Flow                             │
└─────────────────────────────────────────────────────────────────┘

User Request (Browser)
      │
      ▼
┌──────────────┐
│  Nginx       │  Frontend Container
│  Port 80     │  • Serves React build
└──────┬───────┘  • Static files
       │          • index.html
       ▼
┌──────────────┐
│  React App   │  Client-side
│  JavaScript  │  • Routing
└──────┬───────┘  • State management
       │          • UI rendering
       ▼
   API Call
       │
       ▼
┌──────────────┐
│  Express     │  Backend Container
│  Port 3030   │  • Route handling
└──────┬───────┘  • Authentication
       │          • Business logic
       ▼
   DB Query
       │
       ▼
┌──────────────┐
│  MongoDB     │  Database Container
│  Port 27017  │  • Data storage
└──────┬───────┘  • Query processing
       │          • Indexes
       ▼
   Response
       │
       └──────────────┐
                      ▼
              ┌──────────────┐
              │  User        │
              │  (Browser)   │
              └──────────────┘
```

---

This architecture provides:
- ✅ **Scalability**: Easy to add more services
- ✅ **Reliability**: Health checks and restarts
- ✅ **Security**: Multiple layers of protection
- ✅ **Maintainability**: Clear separation of concerns
- ✅ **Portability**: Works across environments
- ✅ **Observability**: Built-in monitoring
