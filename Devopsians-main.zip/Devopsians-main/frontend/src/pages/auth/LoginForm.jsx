// src/pages/LoginForm.jsx
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { loginUser } from '../../utils/api';
import { saveSession } from '../../utils/cookieUtils';
import { useAuth } from '../../contexts/AuthContext';
import styles from './LoginForm.module.css';
import Button from '../../components/common/Button';

const LoginForm = () => {
    const [credentials, setCredentials] = useState({ emailOrUsername: '', password: '' });
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();
    const { login } = useAuth();

    const handleChange = (e) => {
        setCredentials({ ...credentials, [e.target.name]: e.target.value });
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        try {
            const response = await loginUser(credentials);
            const { token, role, user } = response.data;
            const effectiveRole = role || user?.role || '';

            // Save session with user data
            saveSession(token, effectiveRole, user);
            login(token, effectiveRole);

            let path = '/';
            const roleKey = (effectiveRole || '').toString().toLowerCase();
            switch (roleKey) {
                case 'admin': path = '/admin'; break;
                case 'manager': path = '/manager'; break;
                    case 'patient': path = '/patient-dashboard'; break;
                    case 'receptionist': path = '/receptionist'; break;
                case 'ambulance': path = '/ambulance'; break;
                default: path = '/';
            }
            navigate(path, { replace: true });
        } catch (err) {
            setError(err.response?.data?.message || 'Login failed. Check your credentials.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className={styles.container}>
            <form onSubmit={handleLogin} className={styles.formCard}>
                <h2 className={styles.title}>Welcome Back</h2>
                {error && <div className={styles.errorMessage}>{error}</div>}

                <label className={styles.label}>Email or Username:</label>
                <input
                    type="text"
                    name="emailOrUsername"
                    value={credentials.emailOrUsername}
                    onChange={handleChange}
                    disabled={loading}
                    className={styles.inputField}
                    placeholder="Enter your email or username"
                    required
                />
                <label className={styles.label}>Password:</label>
                <input
                    type="password"
                    name="password"
                    value={credentials.password}
                    onChange={handleChange}
                    disabled={loading}
                    className={styles.inputField}
                    required
                />
                
                <Button type="submit" variant="success" disabled={loading}>
                    {loading ? 'Authenticating...' : 'Login'}
                </Button>
                
                <div className={styles.linksContainer}>
                    <Link to="/register" className={styles.registerLink}>Register as Patient</Link>
                    <Link to="/forgot-password" className={styles.forgotLink}>Forgot Password?</Link>
                </div>
            </form>
        </div>
    );
};
export default LoginForm;